#include <iostream>
#include <vector>
#include <fstream>

using namespace std;

int max(int a, int b){
    return (a > b) ? a: b; // return the bigger one
}


int KnapSack(int W, int n, int val[], int wt[], vector<vector<int> >& bag, int index){
    int V[n+1][W+1]; //initialize the table. (row: 0 ~ n, column: 0 ~ W)
    for(int w = 0; w <=W; w++){
        V[0][w] = 0; //setting the starting value of the table
    }
    for(int i = 1; i <=n;i++){
        V[i][0] = 0; // setting the starting value of the table
        for(int w = 1; w <= W;w++){
            if(wt[i-1] <= w){ //
                if(val[i-1]+V[i-1][w-wt[i-1]] > V[i-1][w]){ // if it will maximize the value
                    V[i][w] = val[i-1] + V[i-1][w-wt[i-1]]; // add the current value with cumulated value
                }
                else{
                    V[i][w] = V[i-1][w]; // copy the previous entry
                }
            }
            else{
                V[i][w] = V[i-1][w]; // copy the previous entry
            }
        }
    }
    // track item
    int idx = n, k = W; // starts from the last entry of the table

    while(idx != 0){ // keep tracks diffrent entries until confront row of zeros and column of zeros
        if(V[idx][k] != V[idx-1][k]){
            bag[index].push_back(idx); // record the item number
            k = k-wt[idx-1]; //subtract the weight of item from variable 'k'
            idx--; 
        }
        else{
            idx--;
        }
    }
    // retuirns max value
    return V[n][W];
}
int main(){
    ifstream file("shopping.txt", ios::in);
    int testcase;
    
    file >> testcase; // read #of testcase

    int size;
    int family;
    int Weight;

    while(testcase  != 0){ // iterate as # of testcase

        int total = 0; // initialize total price
        file >> size; // read the amount of items
        
        int val[size]; // initialize price array
        int wt[size]; // initailize weight array

        for(int i = 0; i < size; i++){  
            file >> val[i] >> wt[i]; // reads value and weight of each item
        }

        file >> family; // read the family size
        vector<vector <int> > bag(family); // initalize 2d array as the size of family(row) - row initialize

        //solve knapsack problem for each family member
        for(int i = 0; i < family; i++){
            file >> Weight; // max Weight of each familiy member can pack
            total += KnapSack(Weight, size, val, wt, bag, i); // adds the total max value which each family packed
        }

      //printing part
       cout << "Test Case " << 5-testcase << endl;
       cout << "Total Price " << total << endl;

       for(int i = 0; i < bag.size();i++){ // iterates as the size of the family
           cout << i+1 << ": ";
           for(int j = 0; j < bag[i].size();j++){ // each family member can pack the items independently
               cout << bag[i][bag[i].size()-1-j] << " "; // prints the index of vector reversly because of using '.push_back'.
           }
           cout << endl;
       }

        cout << endl;
        
        testcase--;

    }
    return 0;
}