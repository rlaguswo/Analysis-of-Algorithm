#include <iostream>
#include <fstream>
#include <cstdlib>
#include <chrono>

using namespace std;

int max(int a, int b){
    return (a > b) ? a: b; // return the bigger one
}

int RecKnapSack(int W, int n, int val[], int wt[]){ // knapsack starts from the last index of the item
    if(n == 0 || W == 0){ // base case - stopping criterion
        return 0;
    }

    if(wt[n-1] > W){ // if the value overs maximum Weight permitted
        return RecKnapSack(W, n-1, val, wt); // go to previous item
    }
    else{
        return max(val[n-1]+RecKnapSack(W-wt[n-1], n-1, val, wt), RecKnapSack(W, n-1, val, wt)); //choose bigger value
    } 
}

int DPKnapSack(int W, int n, int val[], int wt[]){
    int V[n+1][W+1]; // intialize the table
    
    for(int w = 0; w <=W; w++){
        V[0][w] = 0;//setting the starting value of the table
    }
    for(int i = 1; i <=n;i++){
        V[i][0] = 0; //setting the starting value of the table
        for(int w = 1; w <= W;w++){
            if(wt[i-1] <= w){
                if(val[i-1]+V[i-1][w-wt[i-1]] > V[i-1][w]){ // if it will maximize the value
                    V[i][w] = val[i-1] + V[i-1][w-wt[i-1]]; // add the current value with cumulated value
                }
                else{
                    V[i][w] = V[i-1][w]; //copy previous entry
                }
            }
            else{
                V[i][w] = V[i-1][w]; // copy previous entry
            }
        }
    }
    return V[n][W]; // return max value
}

int main(){
    //total running time
    int index = 0;
    
    // item variables
    int n = 20; //Wanted to start with 50, but consume too much time. 20 was adequate to average running time
    int W = 1000; // 1000 << 2^20 -> O(Wn) << O(n2^n)

    //data collection variables
    int a = 0, b = 0;
    double recAvg = 0, dpAvg = 0;

     while(index != 5){
         srand(time(NULL));
         int val[n];
         int wt[n];
         for(int i = 0; i < n; i++){
             val[i] = rand()% (W*n); // initialize value of items
             wt[i] = rand()% (W+1); // initialize weight of items -- makes some items which overweights capacity of knapsack
         }
        
         //averaging runnting time of both Recursion knapsack and dynammic programming knapsack
         //will run both solution for 10 times
        for(int i = 0; i < 10; i++){
             auto start = chrono::high_resolution_clock::now();
              a = RecKnapSack(W, n, val, wt);
             auto end = chrono::high_resolution_clock::now();
             chrono::duration<double, milli> period = end - start; 
             recAvg += period.count();

             auto start2 = chrono::high_resolution_clock::now();
             b = DPKnapSack(W, n, val, wt);
             auto end2 = chrono::high_resolution_clock::now();
             chrono::duration<double, milli> period2 = end2 - start2;
             dpAvg += period2.count(); 
        }
        a /= 10; b /= 10;
       //Programming error checking//if(a!=b){cout << "!!ERROR!!" << endl;} 
       cout << endl;
        //printing part
        cout << "N=" << n << " W= " << W << " Rec time = " << recAvg/10 << " DP time = " << dpAvg/10 << " Rec max = " << a << " DP max = " << b << endl;
		  cout << endl;
        n += 20;
        index++;
     }
    return 0;
}
