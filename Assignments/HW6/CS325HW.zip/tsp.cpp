#include <iostream>
#include <fstream>
#include <vector>
#include <cmath>
#include <string>

using namespace std;
 
// Calculate the cost between each vertex. 
int CalCost(int a, int b, int c, int d){
    int e = a - b;
    int f = c - d;

    e *= e; f *= f;
    e += f;
    // Round off the square root values. 
    float result = sqrt(e);
    float result2 = floor(result + 0.5);

    int cost = result2;

    return cost;
}

// Fills the distance matrix with calculated cost between vertices. 
// Since the graph is complete, adjacency matrix is chosen. 
void Matrix(int start[], int end[], vector< vector <int> >& matrix, int Num){
    	for(int i = 0; i < Num; i++){
		    for(int j = 0; j < Num; j++){
			    int a = CalCost(start[i], start[j], end[i], end[j]);
			    // Fill the adjacency matrix
			    matrix[i].push_back(a); 
            }
		}
}

// Extract minimum weight of unvisited vertex among key values
int extractMin(int key[],int check[], int vNum){
	// set min infinite in order to not to affect key values.
	// Key array is initalized by setting all elements as infinite. 
	// Index will always change in the loop, I just set it 0.
	int min = 2147483647, index = 0;  

	for(int i = 0; i < vNum; i++){
		//check the key index which is unvisited.
		// Update pre-set minimum value
		if(min > key[i] && check[i] == 0){  
			index = i;
			min = key[i];
		}
	}

return index;
}


// Find MST in the graph by using Prim's algorithm
void pMST(vector<vector <int> >& matrix, int vNum, vector< vector <int> >& MST){ 
	int key[vNum]; // Key value array
	int check[vNum]; //check if the vertex is visited to prevent cycles.
	int parent[vNum]; // parent pointer

	// Initialize the key, check, and parent array
	for(int i = 0; i < vNum; i++){
		// Set all key values as Infinity. 
		//(I set actaul value of INT_MAX for replacing infinite and not adding another library) 
		key[i] = 2147483647;  
		// All vertex is unvisited. 
		check[i] = 0; 
		 
	}

	// Initialize the root of MST
	key[0] = 0;
	
	// Search all adjacency matrix --> So, O(n^2)
	for(int i = 0; i < vNum; i++){
		//Extract index which has minimum key value among unvisited vertex.
		int u = extractMin(key, check, vNum); 
		// Extracted vertex is visited. 
		check[u] = 1;
		// Since the graph is complete, every vertex is adjacent. 
		for(int j = 0; j < vNum; j++){
			//Avoid the vertex itself
			if(matrix[u][j] != 0){ 
				// update key value of unvisited vertex. 
				if((matrix[u][j] < key[j]) && (check[j] == 0)){ 
						//Set the parent vertex in case of tracking process of algorithm.
						parent[j] = u; 
						// Update key value
						key[j] = matrix[u][j]; 
				}
			}
		}
		// Add key value of visited vertex in the graph to MST weight. 
	}
    
    // Construct MST vector to store the information about MST.
    vector<int> bag; //Auxilary bag
    // start from index 1 of the parrent array
    // parent[0] is NULL
    for(int i = 1; i < vNum; i++){
        bag.push_back(parent[i]);
        bag.push_back(i);
        MST.push_back(bag);
        bag.clear();
    }

}

void DFS(int* adjacent[], int vNum, int start, int visited[], vector<int>& index)
{
    // push the visited vertex to index array.
    index.push_back(start);
    // update that the vertex is visited. 
    visited[start] = 1;

    // Iterate the step above for rest of the vertices
    // First search entire of the columns corresponding row of adjacency matrix 
    // If other vertex is adjacent and unvisited, 
    // go to that vertex
    // Used recursive. 
    for(int i = 0; i < vNum;i++){   
        // If start is equal to i, then skip the loop
        if(start == i){
            continue;
        }
        // check the vertex is adjacent and unvisited. 
        if(adjacent[start][i] == 1 && visited[i] == 0)
        {
            // Recursively do DFS
            DFS(adjacent,vNum,i,visited, index);   
        }
    }
}


int main(int argc, char** argv){
    // Reads the inputfile from the command line. 
    string c = argv[1]; 
	fstream file(argv[1], ios::in);

    // Reads the number of vertices of the graph,
    // and cost initialization
    int vNum = 0, cost = 0; 
    file >> vNum;
   
    // A buffer reading the number of city. 
    // Since the order of cities keep follows during the entire execution,
    // The information about order of cities are not used.
    int buffer;
    // array for x-coordinate of the city
    int start[vNum];
    // array for y-coordinate of the city
    int end[vNum];
    
    // Distance matrix initialization 
    vector<vector <int> > matrix (vNum);
    // MST vector intialization
    vector<vector <int> > MST;
    // Index array initialization
    vector<int> index;
    // Read the contents from the input file, and fill the arrays. 
    // Set the all vertices are unvisited.  
    for(int i = 0; i < vNum; i++){  
		file >> buffer >> start[i] >> end[i];
      
	}
 
    // Fill the distance matrix. 
    Matrix(start, end, matrix, vNum);

    // construct MST by using Prim's algorithm
    pMST(matrix, vNum, MST);

    // construct adjacency matrix 
    // Used dynamic 2-D array for reference
    int** adjacent = new int* [vNum];
    for(int i = 0; i < vNum; i++)
    {
        adjacent[i] = new int[vNum];
        for(int j = 0; j < vNum; j++)
        {
            adjacent[i][j] = 0;
        }
    }
    // Initialize the adjacency matrix 
    // All vertices are unvisited. 
    for(int i = 0; i < MST.size(); i++)
    {
        int row = MST[i][0];
        int column = MST[i][1];
        adjacent[row][column] = 1;
        adjacent[column][row] = 1;
    }

    // Initialize the array which checking if the vertex is visited. 
    int visited[vNum];
    for(int i = 0; i < vNum; i++)
    {
        visited[i] = 0;
    }

    // Do DFS, and push the visited vertex to index. 
    DFS(adjacent, vNum, 0, visited, index);
    // push back the first element to index array to make cycle. 
    index.push_back(index[0]);
    
    // Calculate the total cost by using distance matrix. 
    // Reassuring the cost to start at 0.
    cost = 0;
    for(int i = 1; i <= index.size()-1; i++){
        cost += matrix[index[i-1]][index[i]];
    }
   
    file.close();

   //Parsing the output file depending on the argv[1].
   // Append total cost and visited cities to "tsp_example_*.txt.tour" file.  
    
    // Example 0
   if(c == "tsp_example_0.txt"){
        ofstream File("tsp_example_0.txt.tour", ios_base::app);
        File << cost << endl;
        for(int i = 0; i < vNum; i++){
            File << index[i] << endl;
        }
        File.close();
   }
    // Example 1
	else if(c == "tsp_example_1.txt"){
        ofstream File1("tsp_example_1.txt.tour", ios_base::app);
        File1 << cost << endl;
        for(int i = 0; i < vNum; i++){
            File1 << index[i] << endl;
        }
        File1.close();
    }
    // Example 2
    else if(c == "tsp_example_2.txt"){
        ofstream File2("tsp_example_2.txt.tour", ios_base::app);
        File2 << cost << endl;
        for(int i = 0; i < vNum; i++){
            File2 << index[i] << endl;
        }
        File2.close();
    }
    // Example 3
	else if(c == "tsp_example_3.txt"){
       ofstream File3("tsp_example_3.txt.tour", ios_base::app);
       
        File3 << cost << endl;
        for(int i = 0; i < vNum; i++){
            File3 << index[i] << endl;
        }
        File3.close();
    }
    // Example 4
	else if(c == "tsp_example_4.txt"){
       ofstream File4("tsp_example_4.txt.tour", ios_base::app);
        File4 << cost << endl;
        for(int i = 0; i < vNum; i++){
            File4 << index[i] << endl;
        }
        File4.close();
    
    }
    // Example 5
	else if(c == "tsp_example_5.txt"){
       ofstream File5("tsp_example_5.txt.tour", ios_base::app);
        File5 << cost << endl;
        for(int i = 0; i < vNum; i++){
            File5 << index[i] << endl;
        }
        File5.close();
    }
   
return 0;
}
