#include <iostream>
#include <fstream>
#include <vector>
#include <cmath>

//Our graph is complete graph. So we will use adjancy matrix.

using namespace std;

// Calculate the weight between each vertex.
int Cal(int a, int b, int c, int d){
	int e = a - b;
	int f = c - d;

	// e = (a-b)^2, f = (c-d)^2
	e *= e; f *= f; 
	e += f;
	float result = sqrt(e);

	// round off the distance vectors into integer values.
	float result2 = floor(result + 0.5);  
	//For instance: 
	// We're using integer value
	// Ex1) cal = 14 (result = 13.8, result2 = floor(13.8+0.5) = floor(14.3) = 14.00)
	// Ex2) 12.2 -> floor(12.7) = 12.00. 
	// If there's no round off process, the output will be different from the expectation with correct algorithm process. 

	// Throwing off decimal values. Ex) 14.00 -> 14
	// Need to convert it into integer because adjacency matrix only accepts integer. 
	int cal = result2; 

return cal;
}

//Fill the adjancency matrix with calculated weight. 
void CalWeight(int start[], int end[], vector<vector <int> >& matrix, int vNum){
	// Since the graph is complete, we have to calculate distance(wight) between every vertex.
	for(int i = 0; i < vNum; i++){
		for(int j = 0; j < vNum; j++){
			int a = Cal(start[i], start[j], end[i], end[j]);
			// Fill the adjacency matrix
			matrix[i].push_back(a); 
		}
	}
}

// Extract minimum weight of unvisited vertex among key values
int extractMin(int key[],int check[], int vNum){
	// set min infinite in order to not to affect key values.
	// Key array is initalized by setting all elements as infinite. 
	// Index will always change in the loop, I just set it 0.
	int min = 2147483647, index = 0;  

	for(int i = 0; i < vNum; i++){
		//check the key index which is unvisited.
		// Update pre-set minimum value
		if(min > key[i] && check[i] == 0){  
			index = i;
			min = key[i];
		}
	}

return index;
}


// Find MST in the graph by using Prim's algorithm
int pMST(vector<vector <int> >& matrix, int vNum){ 
	int W = 0;

	int key[vNum]; // Key value array
	int check[vNum]; //check if the vertex is visited to prevent cycles.
	int parent[vNum]; // parent pointer

	// Initialize the key, check, and parent array
	for(int i = 0; i < vNum; i++){
		// Set all key values as Infinity. 
		//(I set actaul value of INT_MAX for replacing infinite and not adding another library) 
		key[i] = 2147483647;  
		// All vertex is unvisited. 
		check[i] = 0; 
		 
	}

	// Initialize the root of MST
	key[0] = 0;
	
	// Search all adjacency matrix --> So, O(n^2)
	for(int i = 0; i < vNum; i++){
		//Extract index which has minimum key value among unvisited vertex.
		int u = extractMin(key, check, vNum); 
		// Extracted vertex is visited. 
		check[u] = 1;
		// Since the graph is complete, every vertex is adjacent. 
		for(int j = 0; j < vNum; j++){
			//Avoid the vertex itself
			if(matrix[u][j] != 0){ 
				// update key value of unvisited vertex. 
				if((matrix[u][j] < key[j]) && (check[j] == 0)){ 
						//Set the parent vertex in case of tracking process of algorithm.
						parent[j] = u; 
						// Update key value
						key[j] = matrix[u][j]; 
				}
			}
		}
		// Add key value of visited vertex in the graph to MST weight. 
		W += key[u]; 
	}

return W;
}

int main(){
	ifstream file("graph.txt", ios::in);
	int testcase = 0, vNum = 0, MST = 0, index = 1;
	
	// Read number of testcase from text file.
	file >> testcase;

	while(testcase != 0){
		// Read number of vertex from text file.
		file >> vNum;

		// Set coordinate arrays to calculate weight of edges. 
		int start[vNum];
		int end[vNum];

		// Initialize adjacency matrix's row with the amount of vertex in the graph.
		// Used 2d vector in convenience of using references. 
		vector<vector <int> > matrix (vNum);   

		//Read points from text file.
		for(int i = 0; i < vNum; i++){  
			file >> start[i] >> end[i];
		}
		//Fill the adjacency matrix 
		CalWeight(start, end, matrix, vNum);
		// Caculate MST Weight by using Prim's algorithm.
		MST = pMST(matrix, vNum);

		//Printing Parts
		cout << "Test case " << index << ": MST weight " << MST << endl;
		cout << endl;
		
		// This is for printing outputs.
		index++; 
		// Decrements testcase to go over next test case. 
		testcase--; 
	}

	file.close();
return 0;
}
