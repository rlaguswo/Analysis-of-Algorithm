#include <iostream>
#include <vector>
#include <fstream>

using namespace std;

void greedAct(int start[], int end[], int act[],int actNum, vector<int>& bag, int& count){
    int n = actNum;
    int i = 0;
    bag.push_back(act[0]); // first push the largest starting time to the bag. 
    for(int m = 1; m < n ; m++){
        if(end[m] <= start[i]){ // if start is greater than or equal to other end array, then push it to the bag. 
            bag.push_back(act[m]);
            count++;
            i = m; // now comparision is starting from pushed index
        }
    }
}

void merge(int arr1[], int arr2[], int arr3[], int start, int mid, int end){ // sort array1 as descending order. Other arrays follow the track of start-array. 
    int leftSize = mid - start + 1; // ex) 0 1(mid) 2 3 -> mid = (int)3/2 = 1, size [0, 1]= 2 = 1(mid)-0(start)+1
    int rightSize = end - mid; // ex)0 1(mid) 2 3(end) -> size [2, 3] = 2 = 3(end) - 1(mid)

    // make left and right subarrays
    int leftArr[leftSize];
    int rightArr[rightSize];
    
    int endleft[leftSize];
    int endright[rightSize];

    int actleft[leftSize];
    int actright[rightSize];

    //fill the subarrays
    for(int i = 0; i < leftSize; i++){
        leftArr[i] = arr1[start + i];
        endleft[i] = arr2[start+i]; // end array pushed to temp array
        actleft[i] = arr3[start+i]; // activity array pushed to temp array
    }
    for(int j = 0; j < rightSize; j++){
        rightArr[j] = arr1[j + mid+1];
        endright[j] = arr2[j + mid+1];
        actright[j] = arr3[j +mid+1];
    }

    // Now sorting the elements of subarrays
    int leftIndex = 0, rightIndex = 0, mergeIndex = start;

    while(leftIndex != leftSize && rightIndex != rightSize){
        if(leftArr[leftIndex] >= rightArr[rightIndex]){ // sort in descending order
            arr1[mergeIndex] = leftArr[leftIndex];
            arr2[mergeIndex] = endleft[leftIndex]; // follow the track of array1
            arr3[mergeIndex] = actleft[leftIndex]; // follow the track of array1
            leftIndex++;
        }
        else{
            arr1[mergeIndex] = rightArr[rightIndex];
            arr2[mergeIndex] = endright[rightIndex]; // follow the track of start-array
            arr3[mergeIndex] = actright[rightIndex]; // follow the track of start-array
            rightIndex++;
        }
        mergeIndex++;
    }

    // If left array has elements after the preivous step (when the size of array is odd)
    for(int i = leftIndex; i < leftSize;i++){
        arr1[mergeIndex] = leftArr[i];
        arr2[mergeIndex] = endleft[i]; // follow the track of array1
        arr3[mergeIndex] = actleft[i]; // follow the track of array1
        mergeIndex++;
    }
    
    // If right array has elements after the preivous step (when the size of array is odd)
    for(int j = rightIndex; j < rightSize;j++){
        arr1[mergeIndex] = rightArr[j];
        arr2[mergeIndex] = endright[j]; // follow the track of array1
        arr3[mergeIndex] = actright[j]; // follow the track of array1
        mergeIndex++;
    }

}

void mergeSort(int arr1[], int arr2[], int arr3[], int start, int end){ 
    //base case: when it is only one cell in the array, 
    //and solve the problem occours when start = 1 and end = 0.
    if(start >= end){
        return;
    }
    
    //Divide

        int mid = (start + end)/2;

        //recurrsive- has to be post order
        mergeSort(arr1, arr2, arr3, start, mid);
        mergeSort(arr1, arr2, arr3, mid+1, end);
        merge(arr1,arr2, arr3, start, mid, end);
}


int main(){
    ifstream file("act.txt", ios::in);
    int actNum = 0;
    int setNum = 1;
    while(!file.eof()){
        int count = 1;
        file >> actNum;
        int act[actNum];
        int start[actNum];
        int end[actNum];
        vector<int> bag;
        for(int i = 0; i < actNum; i++){
            file >> act[i] >> start[i] >> end[i];
        }

        mergeSort(start,end, act, 0, actNum-1);
        greedAct(start, end, act, actNum, bag, count);
        
		  cout << endl;
        cout << "Set " << setNum << endl;
        setNum++;
        cout << "Maximum number of activities = " << count << endl;
        for(int i = bag.size()-1; 0 <= i; i--){ // print the bag in reverse order
            cout <<" " <<bag[i] << " ";
        }
        cout << endl;
     

    }
    file.close();

}
